waxClass{"ViewController",UIViewController}

function viewDidLoad(self)
self:ORIGviewDidLoad(self)
self:view():setBackgroundColor(UIColor:redColor())
end
